export class BanterModel {
    chance: number;
    delay: number;
    delayVariance: number;
    messages: Array<string>;
}
